<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<!--PIE DE PAGINA FOOTER-->
<footer>
        <strong>Este fue mi blog personal espero que les haya gustado</strong>
        <br>      
        <a><h5>Pagina de la universidad.</h5>
          <h4> 
          <a href="https://www.uacam.mx">Universidad Autonoma de Campeche</a><p> 
          </h4>
        </a> 
    </footer>
 <style>
      footer {
      width: 102.5%;
      background: #202020;
      color: white;
      font-size: 12px;
      padding: 20px 0;
      text-align: center;
      font-size: 1rem;
      padding-bottom: 20px;
    }</style>