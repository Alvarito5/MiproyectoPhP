<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<!--navegacion header-->
<div class="navbar-fixed">
      <nav>
        <div class="nav-wrapper color: light-green">
          <a href= "" class="brand-logo right">Mi blog Personal</a>
          <ul id="nav-mobile" class="left hide-on-med-and-down">
            <li><a href="?menu=home">HOME</a></li>
            <li><a href="?menu=acercade">ACERCA DE..</a></li>
            <li><a href="?menu=contacto">CONTACTO</a></li>
            <li><a href="?menu=login">LOGIN</a></li>
            <li><a href="?menu=datosgenerales">Datos Generales</a></li>
            <li><a href="?menu=datosdeintereses">Datos de intereses</a></li>
          </ul>
        </div>
      </nav>
    </div>