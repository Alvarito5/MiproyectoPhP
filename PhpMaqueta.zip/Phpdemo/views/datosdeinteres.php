<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<div class="row">
            <div class="col s4">
                <div class="card horizontal green">
                  <div class="card-stacked ">
                    <div class="card-content">
                      <p>
                          <h2><q>DATOS INTERESANTES</q></h2> 
                          <h5>
                            Ahora les mostrare por medio de una lista mis datos mas INTERESANTES    o     lo que mas importante
                            que me ha pasado :).
                          </h5>
                          <ol>
                              <li><u>Cuando estaba pequeño comia tierra</u></li>
                              <li><u>Casi le prendo fuego a mi casa</u></li>
                              <li><u>me cai de un arbol</u></li>
                              <li><u>casi simpre me pegaban</u></li>
                            </ol>
  
                          <h2><q>MIS GUSTOS</q></h2> 
                          <p>
                              <li>Me gusta los videojuegos</li>
                              <li>Me gusta estar con mi familia</li>
                              <li>Me gusta practicar <dfn>futbol</dfn></li>
                              </p>
                      </p>
                    </div>
                  </div>
                </div>
            </div>
    </div>