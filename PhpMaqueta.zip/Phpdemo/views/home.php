<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<!--Home bienvenida-->
 <div class="row">
            <div class="col s6">
              <div class="card">
                <div class="card-image">
                  <img src="views/david.jpeg"> 
                  <span class="card-title color black">Alvaro Caballero</span>
                  <a class="btn-floating halfway-fab waves-effect waves-light red"><i class="material-icons">add</i></a>
                </div>
                <style>
                  .card {
                    border: 2px solid rgb(103, 168, 206);
                  }
                </style>
                <div class="card-content">
                  <p>
                    Hola soy alumno de la Universidad Autonoma De Campeche, estoy estudiando la carrera de ingenieria
                    en sistemas computacionales y curso la materia de aplicacion de desarollo web lo que les voy a precentar
                    es mi blog personal con la finalidad de que sepan un poco mas de mi sin mas por el momento les precento
                    mi blog personal :). 
                  </p>
                </div>
              </div>
            </div>
 </div>