<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<div class="row">
<div class="col s6">
              <div class="card grey darken-1">   
                <div class="card-content white-text">  
                  <span class="card-title"><h1>Datos Generales</h1></span>
                  <p>
                  <h5>Edad: 22</h5>
                    <h5>Matricula: 52352</h5>
                    <h5>Carrera: Ingenieria en Sistemas Computacionales</h5>
                    <h5>Ciudad: Campeche</h5>
                    <h5>familia: 1 Hermana y mi Madre</h5>
                    <h5>Mascotas: 1 perro y 1 gato</h5>
                  </p>
                </div>
              </div>
            </div>
    </div